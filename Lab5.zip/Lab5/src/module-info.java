/**
 * 
 */
/**
 * 
 */
module Lab5 {
}